export class User{
    id:number;
    name:string;
    email:string;
    phone:string;
    address:string;
}
export class Product{
       id:number;
       name:string;
       price:string;
       descr:string;
       category:string;

}