import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent {

  constructor(private router:Router){}

  adminlogin(name:any,password:any){
   this.router.navigate(['/','updatecustomer'])
  }
}
